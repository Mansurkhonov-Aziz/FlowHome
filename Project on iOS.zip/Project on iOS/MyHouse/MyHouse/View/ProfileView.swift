//
//  ProfileView.swift
//  MyHouse
//
//  Created by Азизхон Мансурхонов on 24/05/25.
//

import SwiftUI

struct ProfileView: View {
    @AppStorage("isLoggedIn") var isLoggedIn: Bool = false
    @AppStorage("userName") var name: String = "Гость"
    @AppStorage("userEmoji") var userEmoji: String = ""

    @State private var selectedImage: Image? = nil
    @State private var showEdit = false
    @State private var showLogin = false
    @State private var showContactSheet = false
    @State private var showCopiedBanner = false

    @EnvironmentObject var favoritesManager: FavoritesManager
    @EnvironmentObject var chatsManager: ChatsManager

    var isGuest: Bool { !isLoggedIn }

    var body: some View {
        VStack(spacing: 20) {
            Spacer().frame(height: 40)

            ZStack {
                Circle()
                    .fill(Color(.systemBackground))
                    .frame(width: 130, height: 130)
                    .overlay(
                        Circle()
                            .strokeBorder(LinearGradient(colors: [Color.blue, Color.purple], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 4)
                    )
                    .shadow(radius: 6)

                if let selectedImage = selectedImage {
                    selectedImage
                        .resizable()
                        .scaledToFill()
                        .frame(width: 124, height: 124)
                        .clipShape(Circle())
                } else if !userEmoji.isEmpty {
                    Text(userEmoji)
                        .font(.system(size: 60))
                        .frame(width: 124, height: 124)
                        .background(Color.white)
                        .clipShape(Circle())
                } else {
                    Text("🐶")
                        .font(.system(size: 60))
                        .frame(width: 124, height: 124)
                        .background(Color.white)
                        .clipShape(Circle())
                }
            }

            Text("Добро пожаловать!")
                .font(.title2)
                .bold()

            Text(name)
                .foregroundColor(.gray)
                .font(.headline)

            Text("🏡 Найди жильё мечты")
                .foregroundColor(.gray)
                .font(.subheadline)

            HStack {
                VStack {
                    Text("\(favoritesManager.favorites.count)")
                        .font(.title2)
                        .bold()
                    Text("Избранное")
                        .font(.caption)
                        .foregroundColor(.gray)
                }

                Divider()
                    .frame(height: 40)
                    .padding(.horizontal)

                VStack {
                    Text("\(chatsManager.chatApartments.count)")
                        .font(.title2)
                        .bold()
                    Text("Сообщения")
                        .font(.caption)
                        .foregroundColor(.gray)
                }
            }
            .padding(.top, 8)

            if !isGuest {
                Button(action: {
                    showEdit = true
                }) {
                    Text("Редактировать профиль")
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(12)
                        .padding(.horizontal)
                }

                Button(action: logout) {
                    Text("Выйти из аккаунта")
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.red)
                        .cornerRadius(12)
                        .padding(.horizontal)
                }
            } else {
                Button(action: {
                    showLogin = true
                }) {
                    Text("Авторизоваться")
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(12)
                        .padding(.horizontal)
                }
            }

            Button(action: {
                showContactSheet = true
            }) {
                HStack(spacing: 6) {
                    Image(systemName: "info.circle.fill")
                    Text("Связь с разработчиком")
                }
                .foregroundColor(.blue)
                .font(.footnote)
                .padding(8)
                .background(Color(.systemGray6))
                .cornerRadius(10)
            }

            .sheet(isPresented: $showContactSheet) {
                VStack(spacing: 20) {
                    Capsule()
                        .fill(Color.white.opacity(0.3))
                        .frame(width: 40, height: 5)
                        .padding(.top)

                    Text("Связаться с разработчиком")
                        .font(.headline)

                    Button(action: {
                        if let url = URL(string: "https://t.me/d3f4ult01") {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Label("Telegram", systemImage: "paperplane.fill")
                    }

                    Button(action: {
                        if let url = URL(string: "mailto:manazizhon@mail.ru") {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Label("Написать на почту", systemImage: "envelope.fill")
                    }

                    Button(action: {
                        UIPasteboard.general.string = "+998881502757"
                        withAnimation {
                            showCopiedBanner = true
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                            withAnimation {
                                showCopiedBanner = false
                            }
                        }
                    }) {
                        Label("Скопировать номер", systemImage: "phone.fill")
                    }

                    Spacer()
                        .foregroundColor(.red)
                        .padding(.bottom)
                }
                .padding()
                .presentationDetents([.height(260)])
            }

            Spacer()

            HStack {
                Spacer()
                Text("by aziz")
                    .font(.footnote)
                    .italic()
                    .foregroundColor(.gray)
                    .padding(.trailing, 16)
                    .padding(.bottom, 6)
            }
        }
        .sheet(isPresented: $showEdit) {
            EditProfileView(name: $name, selectedImage: $selectedImage)
        }
        .sheet(isPresented: $showLogin) {
            PhoneLoginView()
        }
        .onAppear {
            if let emoji = UserDefaults.standard.string(forKey: "userEmoji") {
                userEmoji = emoji
            }
        }
        .overlay(
            VStack {
                if showCopiedBanner {
                    Text("📋 Номер скопирован")
                        .font(.subheadline)
                        .padding(.horizontal, 30)
                        .padding(.vertical, 12)
                        .background(Color.white)
                        .foregroundColor(.black)
                        .cornerRadius(25)
                        .shadow(radius: 6)
                        .transition(.move(edge: .top).combined(with: .opacity))
                        .padding(.top, 60)
                }
                Spacer()
            }
        )
    }

    func logout() {
        isLoggedIn = false
        name = "Гость"
        selectedImage = nil
        userEmoji = ""
        UserDefaults.standard.removeObject(forKey: "userName")
        UserDefaults.standard.removeObject(forKey: "userAvatar")
        UserDefaults.standard.removeObject(forKey: "userEmoji")
        UserDefaults.standard.removeObject(forKey: "favorites")
        favoritesManager.favorites.removeAll()

        for key in UserDefaults.standard.dictionaryRepresentation().keys {
            if key.hasPrefix("messages_") || key.hasPrefix("phone_") || key.hasPrefix("landlord_") {
                UserDefaults.standard.removeObject(forKey: key)
            }
        }

        chatsManager.chatApartments.removeAll()
    }
}
