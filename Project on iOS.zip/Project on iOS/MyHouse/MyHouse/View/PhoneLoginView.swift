//
//  PhoneLoginView.swift
//  MyHouse
//
//  Created by Азизхон Мансурхонов on 24/05/25.
//

import SwiftUI

struct PhoneLoginView: View {
    @State private var phoneNumber: String = "+998"
    @State private var showCodeField = false
    @State private var code: String = ""
    @State private var showError = false

    @AppStorage("isLoggedIn") var isLoggedIn: Bool = false
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Вход по номеру телефона")
                    .font(.title2)
                    .bold()

                TextField("Введите номер", text: $phoneNumber)
                    .keyboardType(.phonePad)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(12)
                    .onAppear {
                        if phoneNumber.isEmpty {
                            phoneNumber = "+998"
                        }
                    }

                if showCodeField {
                    SecureField("Введите код", text: $code)
                        .keyboardType(.numberPad)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(12)
                }

                Button(action: {
                    if showCodeField {
                        let trimmed = code.trimmingCharacters(in: .whitespacesAndNewlines)
                        if trimmed == "2555" {
                            isLoggedIn = true
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                                presentationMode.wrappedValue.dismiss()
                            }
                        } else {
                            showError = true
                        }
                    } else {
                        showCodeField = true
                    }
                }) {
                    Text(showCodeField ? "Подтвердить код" : "Получить код")
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(12)
                }

                Spacer()
            }
            .padding()
            .navigationTitle("Авторизация")
        }
        .alert(isPresented: $showError) {
            Alert(
                title: Text("❌ Ошибка"),
                message: Text("Вы ввели неправильный код. Попробуйте ещё раз."),
                dismissButton: .default(Text("Ок"))
            )
        }
    }
}
