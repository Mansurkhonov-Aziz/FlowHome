//
//  TabRouter.swift
//  MyHouse
//
//  Created by Азизхон Мансурхонов on 24/05/25.
//

import SwiftUI

class TabRouter: ObservableObject {
    @Published var selectedTab: Int = 0
    @Published var refreshID = UUID()

    func switchToTab(_ index: Int) {
        if selectedTab == index {
            // если повторно нажали на ту же вкладку — сбросим экран
            refreshID = UUID()
        }
        selectedTab = index
    }
}
