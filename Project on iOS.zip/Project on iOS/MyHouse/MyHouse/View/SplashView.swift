//
//  SplashView.swift
//  FlowHome
//
//  Created by Азизхон Мансурхонов on 26/05/25.
//

import SwiftUI

struct SplashView: View {
    @State private var isActive = false
    @State private var logoOpacity = 0.0
    @State private var searchRotation: Double = -15
    @State private var found = false

    var body: some View {
        if isActive {
            ContentView()
        } else {
            ZStack {
                Color.white.ignoresSafeArea()

                VStack(spacing: 20) {
                    ZStack {
                        Image(systemName: found ? "house.fill" : "magnifyingglass")
                            .resizable()
                            .frame(width: 80, height: 80)
                            .foregroundColor(.yellow)
                            .rotationEffect(.degrees(found ? 0 : searchRotation))
                            .scaleEffect(found ? 1.0 : 1.2)
                            .animation(.easeInOut(duration: 0.5), value: found)
                    }

                    Text("FlowHome")
                        .font(.largeTitle.bold())
                        .foregroundColor(.black)
                        .opacity(logoOpacity)

                    Text("Найди жильё мечты")
                        .font(.headline)
                        .foregroundColor(.gray)
                        .opacity(logoOpacity)
                }
                .opacity(logoOpacity)
            }
            .onAppear {
                withAnimation(.easeIn(duration: 1.2)) {
                    logoOpacity = 1.0
                }

                // Анимация поиска
                Timer.scheduledTimer(withTimeInterval: 1.5, repeats: false) { _ in
                    withAnimation {
                        found = true
                    }
                }

                // Переход к приложению
                DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                    withAnimation {
                        isActive = true
                    }
                }
            }
        }
    }
}

struct SplashView_Previews: PreviewProvider {
    static var previews: some View {
        SplashView()
    }
}
