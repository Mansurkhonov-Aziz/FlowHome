//
//  TagLineView.swift
//  MyHouse
//
//  Created by Азизхон Мансурхонов on 24/05/25.
//

import SwiftUI

struct TagLineView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            // 🌍 Кастомная иконка и город
            HStack(spacing: 8) {
            
                
                Text("📍Ташкент, Узбекистан")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .fontWeight(.medium)
            }
            
            // 🏡 Прямой лозунг
            Text("🏡 Найди жильё мечты")
                .font(.title2.bold())
                .foregroundColor(.primary) // ✅ автоматическая адаптация
                .lineLimit(1)
                .truncationMode(.tail)
        }
        .padding(.horizontal)
        .padding(.top)
    }
}
