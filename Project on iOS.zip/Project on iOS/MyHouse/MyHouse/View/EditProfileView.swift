//
//  EditProfileView.swift
//  MyHouse
//
//  Created by Азизхон Мансурхонов on 24/05/25.
//

import SwiftUI

struct EditProfileView: View {
    @Binding var name: String
    @Binding var selectedImage: Image?

    @Environment(\.presentationMode) var presentationMode

    @State private var isImagePickerPresented = false
    @State private var uiImage: UIImage?

    let sampleStickers = ["🐶", "🌈", "🚀", "🦄", "🍩", "🎮", "📸", "🏝️"]

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                TextField("Ваше имя", text: $name)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)

                Text("Выберите аватар:")
                    .font(.headline)

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 20) {
                        ForEach(sampleStickers, id: \.self) { sticker in
                            Button(action: {
                                selectedImage = Text(sticker).asImage(size: 130)
                                UserDefaults.standard.set(sticker, forKey: "userEmoji")
                            }) {
                                Text(sticker)
                                    .font(.system(size: 50))
                                    .frame(width: 70, height: 70)
                                    .background(Color.gray.opacity(0.1))
                                    .clipShape(Circle())
                            }
                        }
                    }
                    .padding(.horizontal)
                }

                Button("Выбрать из галереи") {
                    isImagePickerPresented = true
                }
                .padding()

                Spacer()

                Button("Сохранить") {
                    presentationMode.wrappedValue.dismiss()
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(12)
                .padding(.horizontal)
            }
            .padding(.top)
            .navigationTitle("Редактирование")
            .navigationBarTitleDisplayMode(.inline)
        }
        .sheet(isPresented: $isImagePickerPresented) {
            ImagePicker(selectedImage: $uiImage)
                .onDisappear {
                    if let uiImage = uiImage {
                        selectedImage = Image(uiImage: uiImage)
                        UserDefaults.standard.removeObject(forKey: "userEmoji")
                    }
                }
        }
    }
}

// MARK: - Расширение для конвертации Text в Image
extension Text {
    func asImage(size: CGFloat = 130) -> Image {
        let controller = UIHostingController(rootView: self.font(.system(size: size * 0.6)))
        let view = controller.view

        let targetSize = CGSize(width: size, height: size)
        view?.bounds = CGRect(origin: .zero, size: targetSize)
        view?.backgroundColor = .clear

        let renderer = UIGraphicsImageRenderer(size: targetSize)

        let image = renderer.image { _ in
            view?.drawHierarchy(in: view!.bounds, afterScreenUpdates: true)
        }

        return Image(uiImage: image)
    }
}
