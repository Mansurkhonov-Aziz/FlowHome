//
//  MyHouseApp.swift
//  MyHouse
//
//  Created by Азизхон Мансурхонов on 06/05/25.
//

import SwiftUI

@main
struct MyHouseApp: App {
    var body: some Scene {
        WindowGroup {
            SplashView() // вместо ContentView()
        }
    }
}
