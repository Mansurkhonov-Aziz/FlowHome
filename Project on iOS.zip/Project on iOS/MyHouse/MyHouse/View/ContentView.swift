//
//  ContentView.swift
//  MyHouse
//
//  Created by Азизхон Мансурхонов on 06/05/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject var favoritesManager = FavoritesManager()
    @StateObject var chatsManager = ChatsManager()

    var body: some View {
        MainTabView()
            .environmentObject(favoritesManager)
            .environmentObject(chatsManager)
    }
}
