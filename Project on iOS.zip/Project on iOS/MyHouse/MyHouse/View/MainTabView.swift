//
//  MainTabView.swift
//  MyHouse
//
//  Created by Азизхон Мансурхонов on 24/05/25.
//

import SwiftUI

struct MainTabView: View {
    @StateObject var tabRouter = TabRouter()

    init() {
        let appearance = UITabBarAppearance()
        appearance.configureWithTransparentBackground()
        appearance.backgroundEffect = UIBlurEffect(style: .systemThinMaterial) // 💡 стеклянный эффект
        appearance.backgroundColor = UIColor.systemBackground.withAlphaComponent(0.6) // 💡 прозрачность

        // Настройка цвета иконок и текста
        let itemAppearance = UITabBarItemAppearance()
        itemAppearance.normal.iconColor = .gray
        itemAppearance.selected.iconColor = .systemBlue
        itemAppearance.normal.titleTextAttributes = [.foregroundColor: UIColor.gray]
        itemAppearance.selected.titleTextAttributes = [.foregroundColor: UIColor.systemBlue]

        appearance.stackedLayoutAppearance = itemAppearance
        appearance.inlineLayoutAppearance = itemAppearance
        appearance.compactInlineLayoutAppearance = itemAppearance

        UITabBar.appearance().standardAppearance = appearance
        UITabBar.appearance().scrollEdgeAppearance = appearance
    }

    var body: some View {
        TabView(selection: $tabRouter.selectedTab) {
            HomeScreen()
                .id(tabRouter.refreshID)
                .tabItem {
                    Label("Главная", systemImage: "house.fill")
                }
                .tag(0)

            ChatsListView()
                .tabItem {
                    Label("Чаты", systemImage: "bubble.left.and.bubble.right.fill")
                }
                .tag(1)

            ProfileView()
                .tabItem {
                    Label("Профиль", systemImage: "person.crop.circle.fill")
                }
                .tag(2)
        }
        .environmentObject(tabRouter)
    }
}
