//
//  ChatView.swift
//  MyHouse
//
//  Created by Азизхон Мансурхонов on 24/05/25.

import SwiftUI
import UIKit

struct ChatView: View {
    let apartment: Apartment

    @State private var messages: [ChatMessage] = []
    @State private var inputText: String = ""
    @State private var showPhoneNumber: Bool = false
    @State private var phoneNumber: String = ""

    let responses: [String: String] = [
        "привет": "Здравствуйте! Чем могу помочь?",
        "дом продается?": "Нет, эта квартира только сдаётся в аренду.",
        "какие условия?": "Минимум на 6 месяцев. Без животных.",
        "можно скидку?": "Цена обсуждается при встрече с арендодателем.",
        "согласен взять в аренду": "Отличный выбор! Вот номер арендодателя:"
    ]

    let numbers = [
        "+998 95 316 64 17",
        "+998 99 142 15 12",
        "+998 93 202 78 30",
        "+998 94 997 35 91",
        "+998 95 181 29 51"
    ]

    @EnvironmentObject var chatsManager: ChatsManager
    @Namespace var bottomID

    var body: some View {
        VStack {
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 12) {
                        ForEach(messages) { message in
                            HStack {
                                if message.isUser {
                                    Spacer()
                                    VStack(alignment: .trailing, spacing: 4) {
                                        Text(message.text)
                                            .padding()
                                            .background(
                                                LinearGradient(colors: [.blue, .purple], startPoint: .leading, endPoint: .trailing)
                                            )
                                            .foregroundColor(.white)
                                            .cornerRadius(16)
                                        Text(formattedTime(message.date))
                                            .font(.caption2)
                                            .foregroundColor(.gray)
                                    }
                                } else {
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(message.text)
                                            .padding()
                                            .background(Color.gray.opacity(0.2))
                                            .foregroundColor(.primary)
                                            .cornerRadius(16)
                                        Text(formattedTime(message.date))
                                            .font(.caption2)
                                            .foregroundColor(.gray)
                                    }
                                    Spacer()
                                }
                            }
                            .padding(.horizontal)
                        }

                        if showPhoneNumber {
                            HStack {
                                Spacer()
                                Text("📞 \(phoneNumber)")
                                    .padding()
                                    .background(
                                        LinearGradient(colors: [.blue, .purple], startPoint: .leading, endPoint: .trailing)
                                    )
                                    .foregroundColor(.white)
                                    .cornerRadius(16)
                                    .onTapGesture {
                                        UIPasteboard.general.string = phoneNumber
                                        showCopiedAlert()
                                    }
                                Spacer()
                            }
                        }

                        Color.clear.frame(height: 1).id(bottomID)
                    }
                    .padding(.top)
                }
                .onChange(of: messages.count) { _ in
                    withAnimation {
                        proxy.scrollTo(bottomID, anchor: .bottom)
                    }
                }
            }

            Divider()

            HStack {
                TextField("💬 Напишите сообщение...", text: $inputText)
                    .padding(12)
                    .background(Color(.systemGray6))
                    .cornerRadius(20)
                    .foregroundColor(.primary)
                    .onAppear {
                        let emoji = "💬 "
                        if inputText.isEmpty {
                            inputText = emoji
                        } else if !inputText.hasPrefix(emoji) {
                            inputText = emoji + inputText
                        }
                    }

                Button(action: sendMessage) {
                    Image(systemName: "arrow.up.circle.fill")
                        .font(.system(size: 28))
                        .foregroundColor(.blue)
                }
                .disabled(inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            .padding(.horizontal)
            .padding(.bottom, 8)
        }
        .navigationTitle("Чат")
        .onAppear {
            messages = MessageStorage.loadMessages(for: apartment.id)
            phoneNumber = MessageStorage.loadPhoneNumber(for: apartment.id) ?? ""
            showPhoneNumber = !phoneNumber.isEmpty
            chatsManager.addChat(for: apartment)
        }
    }

    func sendMessage() {
        let trimmed = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }

        let userMessage = ChatMessage(id: UUID(), text: trimmed, isUser: true, date: Date())
        messages.append(userMessage)
        MessageStorage.saveMessages(messages, for: apartment.id)
        chatsManager.addChat(for: apartment)
        inputText = "💬 "

        let lowercased = trimmed.lowercased()

        if lowercased.contains("согласен взять в аренду") {
            showPhoneNumber = true
            phoneNumber = numbers.randomElement() ?? "+998 90 000 00 00"
            let botReply = responses["согласен взять в аренду"] ?? ""
            let reply = ChatMessage(id: UUID(), text: botReply, isUser: false, date: Date())
            messages.append(reply)
            MessageStorage.saveMessages(messages, for: apartment.id)
            MessageStorage.savePhoneNumber(phoneNumber, for: apartment.id)
        } else if let reply = responses.first(where: { lowercased.contains($0.key) })?.value {
            let replyMsg = ChatMessage(id: UUID(), text: reply, isUser: false, date: Date())
            messages.append(replyMsg)
            MessageStorage.saveMessages(messages, for: apartment.id)
        }
    }

    func deleteMessage(at offsets: IndexSet) {
        messages.remove(atOffsets: offsets)
        MessageStorage.saveMessages(messages, for: apartment.id)
    }

    func formattedTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }

    func showCopiedAlert() {
        let alert = UIAlertController(title: nil, message: "Номер скопирован", preferredStyle: .alert)
        UIApplication.shared.windows.first?.rootViewController?.present(alert, animated: true)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
            alert.dismiss(animated: true)
        }
    }
}
