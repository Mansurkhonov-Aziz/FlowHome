//
//  ChatsListView.swift
//  MyHouse
//
//  Created by Азизхон Мансурхонов on 24/05/25.
//

import SwiftUI

struct ChatsListView: View {
    @EnvironmentObject var chatsManager: ChatsManager
    @State private var showDeleteConfirmation = false
    @State private var apartmentToDelete: Apartment?

    var body: some View {
        NavigationView {
            VStack(alignment: .leading) {
                HStack {
                    Text("Чаты")
                        .font(.system(size: 32, weight: .bold))
                    Spacer()
                }
                .padding([.horizontal, .top])

                ScrollView {
                    VStack(spacing: 16) {
                        ForEach(chatsManager.chatApartments) { apartment in
                            HStack(spacing: 12) {
                                NavigationLink(destination: ChatView(apartment: apartment)) {
                                    HStack(spacing: 12) {
                                        Image(apartment.images.first ?? "")
                                            .resizable()
                                            .scaledToFill()
                                            .frame(width: 84, height: 84)
                                            .clipShape(RoundedRectangle(cornerRadius: 12))
                                            .shadow(radius: 2)

                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(apartment.title)
                                                .font(.subheadline)
                                                .foregroundColor(.primary)

                                            if let last = MessageStorage.loadMessages(for: apartment.id).last {
                                                Text(formattedDate(last.date))
                                                    .font(.caption)
                                                    .foregroundColor(.secondary)
                                            }
                                        }

                                        Spacer()
                                    }
                                    .padding()
                                    .background(
                                        RoundedRectangle(cornerRadius: 18)
                                            .fill(Color(.systemGray6))
                                            .shadow(color: Color.black.opacity(0.05), radius: 4, x: 0, y: 2)
                                    )
                                }

                                Button(action: {
                                    apartmentToDelete = apartment
                                    showDeleteConfirmation = true
                                }) {
                                    Image(systemName: "trash.circle.fill")
                                        .resizable()
                                        .frame(width: 24, height: 24)
                                        .foregroundColor(.red)
                                        .padding(.trailing, 4)
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                    .padding(.top)
                }
            }
            .background(Color(.systemBackground))
            .navigationBarHidden(true)
            .alert(isPresented: $showDeleteConfirmation) {
                Alert(
                    title: Text("Удалить чат? 🗑️"),
                    message: Text("Вы уверены, что хотите удалить этот чат?"),
                    primaryButton: .destructive(Text("Удалить")) {
                        if let apartment = apartmentToDelete,
                           let index = chatsManager.chatApartments.firstIndex(where: { $0.id == apartment.id }) {
                            chatsManager.chatApartments.remove(at: index)
                        }
                    },
                    secondaryButton: .cancel()
                )
            }
        }
    }

    func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "ru_RU")
        formatter.dateFormat = "d MMMM"
        return formatter.string(from: date)
    }
}
