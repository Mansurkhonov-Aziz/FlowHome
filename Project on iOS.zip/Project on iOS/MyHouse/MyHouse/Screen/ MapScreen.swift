//
//   MapScreen.swift
//  FlowHome
//
//  Created by Азизхон Мансурхонов on 08/06/25.
//

import SwiftUI
import MapKit

struct MapScreen: View {
    let apartments: [Apartment]
    @Binding var showMap: Bool

    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 41.3111, longitude: 69.2797),
        span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
    )

    @State private var selectedApartment: Apartment?
    @State private var showDetail = false

    var body: some View {
        NavigationView {
            ZStack(alignment: .topLeading) {
                Map(coordinateRegion: $region, annotationItems: apartments) { apartment in
                    MapAnnotation(coordinate: CLLocationCoordinate2D(latitude: apartment.latitude, longitude: apartment.longitude)) {
                        Button(action: {
                            selectedApartment = apartment
                        }) {
                            Image(systemName: "house.circle.fill")
                                .resizable()
                                .frame(width: 32, height: 32)
                                .foregroundColor(.blue)
                                .shadow(radius: 3)
                        }
                    }
                }
                .ignoresSafeArea()

                Button(action: {
                    showMap = false
                }) {
                    HStack {
                        Image(systemName: "chevron.left")
                        Text("Назад")
                    }
                    .padding(10)
                    .background(.thinMaterial)
                    .cornerRadius(10)
                    .padding()
                }

                // 📌 Мини-карточка внизу
                if let apartment = selectedApartment {
                    VStack {
                        Spacer()

                        VStack(spacing: 12) {
                            HStack(spacing: 12) {
                                Image(apartment.images.first ?? "")
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 70, height: 70)
                                    .clipShape(RoundedRectangle(cornerRadius: 12))

                                VStack(alignment: .leading, spacing: 4) {
                                    Text(apartment.title)
                                        .font(.headline)
                                        .lineLimit(1)

                                    Text(apartment.location)
                                        .font(.subheadline)
                                        .foregroundColor(.gray)

                                    Text(apartment.price)
                                        .font(.subheadline.bold())
                                        .foregroundColor(.green)
                                }

                                Spacer()

                                Button(action: {
                                    showDetail = true
                                }) {
                                    Text("Подробнее")
                                        .font(.caption)
                                        .foregroundColor(.white)
                                        .padding(.horizontal, 14)
                                        .padding(.vertical, 8)
                                        .background(Color.blue)
                                        .cornerRadius(10)
                                }
                            }
                        }
                        .padding()
                        .background(.ultraThinMaterial)
                        .cornerRadius(18)
                        .shadow(radius: 8)
                        .padding(.horizontal)
                        .padding(.bottom, 20)
                        .transition(.move(edge: .bottom))
                    }
                }

                // 🌐 Переход к DetailScreen
                NavigationLink(
                    destination: selectedApartment.map { DetailScreen(apartment: $0) },
                    isActive: $showDetail
                ) {
                    EmptyView()
                }
            }
            .navigationBarHidden(true)
        }
    }
}
