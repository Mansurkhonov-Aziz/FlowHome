//
//  ApartmentCardView.swift
//  MyHouse
//
//  Created by Азизхон Мансурхонов on 24/05/25.
//

import SwiftUI

struct ApartmentCardView: View {
    let apartment: Apartment

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            // 📸 Фото с горизонтальным скроллингом
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(apartment.images, id: \.self) { imageName in
                        Image(imageName)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 300, height: 170)
                            .clipped()
                            .cornerRadius(12)
                    }
                }
                .padding(.horizontal, 8)
            }

            // 🏠 Название + 💰 Цена
            HStack {
                Text(apartment.title)
                    .font(.headline)
                    .foregroundColor(.primary)

                Spacer(minLength: 16)

                Text(apartment.price)
                    .font(.subheadline)
                    .foregroundColor(.white)
                    .padding(.vertical, 6)
                    .padding(.horizontal, 14)
                    .background(
                        LinearGradient(
                            colors: [Color.blue, Color.purple],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .cornerRadius(20)
            }
            .padding(.horizontal, 12)

            // 🌍 Адрес
            Text(apartment.location)
                .font(.subheadline)
                .foregroundColor(.secondary)
                .padding(.horizontal, 12)
                .padding(.bottom, 8)
        }
        .frame(maxWidth: 370)
        .background(
            RoundedRectangle(cornerRadius: 18)
                .fill(Color(UIColor.systemBackground))
        )
        .shadow(color: Color.black.opacity(colorScheme == .dark ? 0.0 : 0.08), radius: 6, x: 0, y: 4)
        .padding(.horizontal)
    }

    @Environment(\.colorScheme) var colorScheme
}
