//
//  Apartment.swift
//  MyHouse
//
//  Created by Азизхон Мансурхонов on 24/05/25.
//

import Foundation

struct Apartment: Identifiable, Codable, Equatable {
    var id: UUID
    var title: String
    var location: String
    var price: String
    var images: [String]
    var description: String
    var latitude: Double
    var longitude: Double
}
