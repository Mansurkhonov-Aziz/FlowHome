//
//  HomeScreen.swift
//  MyHouse
//
//  Created by Азизхон Мансурхонов on 06/05/25.
//

import SwiftUI

struct DetailScreen: View {
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var favoritesManager: FavoritesManager
    @EnvironmentObject var chatsManager: ChatsManager
    @State private var showContractView = false

    var apartment: Apartment

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {

                // 📸 Скролл фото
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 16) {
                        ForEach(apartment.images, id: \.self) { imageName in
                            Image(imageName)
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 320, height: 220)
                                .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
                                .shadow(radius: 5)
                        }
                    }
                    .padding(.horizontal)
                }

                // 🏷 Название и локация
                VStack(alignment: .leading, spacing: 6) {
                    Text(apartment.title)
                        .font(.title)
                        .bold()

                    Text(apartment.location)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .padding(.horizontal)

                // 📝 Описание
                VStack(alignment: .leading, spacing: 10) {
                    Text("Описание")
                        .font(.headline)

                    Text(apartment.description)
                        .lineSpacing(6)
                        .foregroundColor(.secondary)
                }
                .padding(.horizontal)

                // 🧾 Договор
                Button(action: {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        showContractView = true
                    }
                }) {
                    VStack {
                        Image(systemName: "doc.text.fill")
                            .font(.title2)
                        Text("Договор")
                            .font(.caption)
                    }
                    .foregroundColor(.white)
                    .frame(width: 395, height: 65)
                    .background(Color.green.opacity(0.9))
                    .cornerRadius(20)
                    .shadow(color: .black.opacity(0.2), radius: 5, x: 0, y: 2)
                }
                .scaleEffect(showContractView ? 0.98 : 1.0)

                // 🔘 Кнопки под описанием
                HStack(spacing: 12) {

                    // ❤️ Нравится
                    Button(action: {
                        favoritesManager.toggleFavorite(apartment)
                    }) {
                        VStack {
                            Image(systemName: favoritesManager.favorites.contains(where: { $0.id == apartment.id }) ? "heart.fill" : "heart")
                                .font(.title2)
                            Text("Нравится")
                                .font(.caption)
                        }
                        .foregroundColor(.white)
                        .frame(width: 100, height: 60)
                        .background(Color.red)
                        .cornerRadius(20)
                    }

                    // 💬 Сообщение
                    NavigationLink(destination: ChatView(apartment: apartment)) {
                        VStack {
                            Image(systemName: "message")
                                .font(.title2)
                            Text("Сообщение")
                                .font(.caption)
                        }
                        .foregroundColor(.white)
                        .frame(width: 100, height: 60)
                        .background(Color.blue)
                        .cornerRadius(20)
                    }

                    // 🔗 Поделиться
                    Button(action: {
                        shareApartment(apartment)
                    }) {
                        VStack {
                            Image(systemName: "square.and.arrow.up")
                                .font(.title2)
                            Text("Поделиться")
                                .font(.caption)
                        }
                        .foregroundColor(.white)
                        .frame(width: 100, height: 60)
                        .background(Color.blue)
                        .cornerRadius(20)
                    }
                }
                .padding(.horizontal)
                .padding(.bottom)
            }
            .padding(.top)
        }
        .navigationBarBackButtonHidden(true)
        .navigationBarItems(leading:
            Button(action: {
                presentationMode.wrappedValue.dismiss()
            }) {
                HStack(spacing: 6) {
                    Image(systemName: "chevron.left")
                    Text("Назад")
                }
                .foregroundColor(.blue)
                .padding(.vertical, 8)
                .padding(.horizontal, 12)
                .background(Color(.systemGray6))
                .cornerRadius(10)
            }
        )
    }

    func shareApartment(_ apartment: Apartment) {
        let shareText = "\u{1F4CD} \(apartment.title) в \(apartment.location)\n\u{1F4B0} Цена: \(apartment.price)\nПодробнее в приложении FlowHome"

        let activityVC = UIActivityViewController(activityItems: [shareText], applicationActivities: nil)

        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let rootVC = windowScene.windows.first?.rootViewController {
            rootVC.present(activityVC, animated: true)
        }
    }
}
