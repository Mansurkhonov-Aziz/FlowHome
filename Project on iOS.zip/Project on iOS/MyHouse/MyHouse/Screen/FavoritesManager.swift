//
//  FavoritesManager.swift
//  MyHouse
//
//  Created by Азизхон Мансурхонов on 24/05/25.
//

import SwiftUI

class FavoritesManager: ObservableObject {
    @Published var favorites: [Apartment] = []

    func toggleFavorite(_ apartment: Apartment) {
        if favorites.contains(where: { $0.id == apartment.id }) {
            favorites.removeAll { $0.id == apartment.id }
        } else {
            favorites.append(apartment)
        }
    }

    func isFavorite(_ apartment: Apartment) -> Bool {
        favorites.contains(where: { $0.id == apartment.id })
    }
}
