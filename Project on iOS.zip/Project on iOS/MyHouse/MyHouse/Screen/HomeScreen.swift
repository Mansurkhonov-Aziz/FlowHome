//
//  HomeScreen.swift
//  MyHouse
//
//  Created by Азизхон Мансурхонов on 06/05/25.
//

import SwiftUI
import UIKit

struct HomeScreen: View {
    @EnvironmentObject var favoritesManager: FavoritesManager
    @State private var showGuide = false
    @State private var guideStep = 0
    @State private var showMap = false

    let apartments: [Apartment] = [
        Apartment(id: UUID(), title: "Жилье гостиничного типа", location: "Ташкент", price: "$46", images: ["Home1", "Home1.1", "Home1.2", "Home1.3", "Home1.4", "Home1.5"],  description: "Жилье гостиничного типа без кухни. Это недавно построенная квартира недалеко от Сеула Мун.", latitude: 41.314023, longitude: 69.249086),
        Apartment(id: UUID(), title: "Seoul Mun", location: "Ташкент", price: "$52", images: ["Home2", "Home2.1", "Home2.2", "Home2.3", "Home2.4"],  description: "Расположенное в центре, это жилье отличается удобством расположения и изысканным стилем.", latitude: 41.319996, longitude: 69.243669),
        Apartment(id: UUID(), title: "Зеленая однокомнатная в центре", location: "Ташкент", price: "$75", images: ["Home3", "Home3.1", "Home3.2", "Home3.3", "Home3.4"],  description: "Всё просто: спокойное жилье в центре города. В зеленом сердце столицы, Устройте себе отдых в одном из самых тихих и безопасных мест, Транспортная доступность в любую точку города Рядом все необходимое для комфортного проживания, очень популярная туристическая локация, Ориентир Метро Космонавтов Метро в шаговой доступности 2 мин", latitude: 41.335564, longitude: 69.265723),
        Apartment(id: UUID(), title: "Комфортабельная квартира", location: "Ташкент", price: "$39", images: ["Home4", "Home4.1", "Home4.2", "Home4.3", "Home4.4", "Home4.5"],  description: "Уютная и чистая квартира в очень удобном для туристов месте - в 5 минутах от аэропорта и железнодорожного вокзала. Также 5 минут на такси от центра города или 10 минут на общественном транспорте (5 минут на общественном транспорте от ближайшей станции метро). Ближайшая автобусная остановка находится в 50 метрах. Рядом с квартирой есть несколько продуктовых магазинов и несколько кафе. Неограниченный высокоскоростной интернет.", latitude: 41.318472, longitude: 69.275613),
        Apartment(id: UUID(), title: "Комфортабельная квартира", location: "Ташкент", price: "$31", images: ["Home5", "Home5.1", "Home5.2", "Home5.3", "Home5.4"],  description: "Ищете тихое, бюджетное жилье за пределами оживленного города? Наслаждайтесь спокойным, доступным отдыхом вдали от городского шума. 🛏️ Спальня • Уютная двуспальная кровать и свежее постельное белье. • Smart TV с Интернетом. 🍽️ Кухня: • Плита, холодильник, чайник и посуда. - стол на двоих; • Быстрый Wi-Fi — идеально подходит для работы или потоковой передачи. 🛁 Ванная и дополнительные удобства • Отдельная ванная и горячая вода. • Стиральная машина, утюг и сушилка. 🚖 Легко добраться на такси, рядом магазины и кафе. Мы ценим вашу помощь в экономии энергии. Пожалуйста, выключайте свет, кондиционер и воду, когда они не используются.", latitude: 41.327790, longitude: 69.338648),
        Apartment(id: UUID(), title: "Дизайнерская квартира", location: "Ташкент", price: "$51", images: ["Home6", "Home6.1", "Home6.2", "Home6.3", "Home6.5", "Home6.6"],  description: "Насладитесь стильным отдыхом в центре города, с прекрасным видом на город.", latitude: 41.341781, longitude: 69.334534),
    ]

    var guideSteps: [(title: String, message: String)] = [
            ("🏠 Главный экран", "Здесь отображаются доступные квартиры. Прокручивайте вниз, чтобы просматривать больше."),
            ("🗺 Карта квартир", "Нажмите на иконку карты в правом верхнем углу, чтобы увидеть все квартиры на карте."),
            ("❤️ Избранное", "Нажмите на сердечко в правом верхнем углу, чтобы посмотреть свои избранные квартиры."),
            ("📄 Карточки квартир", "Нажмите на любую квартиру, чтобы открыть подробности и начать общение с арендодателем."),
            ("🧾 Договор аренды", "На экране квартиры нажмите кнопку 'Договор', чтобы сгенерировать PDF-документ и подписать его."),
            ("❤️ Добавление в избранное", "На экране квартиры нажмите на иконку 'сердце', чтобы добавить в избранное."),
            ("💔 Удаление из избранного", "В разделе Избранное проведите влево по элементу, чтобы удалить квартиру."),
            ("🗑 Удаление чата", "Перейдите в чаты, нажмите корзину рядом с нужным чатом, чтобы удалить его."),
            ("🤖 Как работает чат-бот", "Бот отвечает автоматически, если вы напишете 'дом продается?' или 'согласен взять в аренду'."),
            ("👤 Изменить профиль", "В профиле нажмите 'Редактировать', чтобы поменять имя или аватар."),
            ("🔐 Авторизация", "Если вы не авторизованы, нажмите 'Авторизоваться' в профиле."),
            ("📞 Копирование номера", "В чате нажмите на номер телефона, чтобы скопировать его в буфер обмена."),
            ("✅ Всё готово", "Теперь вы знаете, как пользоваться приложением FlowHome. Удачи!")
        ]
    

    var body: some View {
           NavigationView {
               ZStack(alignment: .bottomTrailing) {
                   VStack(alignment: .leading) {
                       HStack {
                           TagLineView()
                           Spacer()

                           // Кнопка карты
                           Button(action: {
                               showMap = true
                           }) {
                               Image(systemName: "globe.asia.australia")
                                   .font(.system(size: 22, weight: .bold))
                                   .foregroundColor(.blue)
                                   .padding(8)
                                   .background(Color(.systemGray5))
                                   .clipShape(Circle())
                           }
                           .fullScreenCover(isPresented: $showMap) {
                               MapScreen(apartments: apartments, showMap: $showMap)
                           }

                           // Избранное
                           NavigationLink(destination: FavoritesScreen()) {
                               Image(systemName: "heart.fill")
                                   .resizable()
                                   .scaledToFit()
                                   .frame(width: 24, height: 24)
                                   .foregroundColor(.red) // или .primary для адаптивности
                                   .padding(.leading, 8)
                           }
                       }
                       .padding([.horizontal, .top])

                       ScrollView {
                           VStack(spacing: 20) {
                               ForEach(apartments) { apartment in
                                   NavigationLink(destination: DetailScreen(apartment: apartment)) {
                                       ApartmentCardView(apartment: apartment)
                                   }
                                   .buttonStyle(PlainButtonStyle())
                               }
                           }
                           .padding(.top)
                       }
                   }
                   .background(Color(.systemBackground)) // 👈 фон адаптируется к теме
                   .navigationBarHidden(true)

                   // Подсказка кнопка 💡
                   Button(action: {
                       withAnimation {
                           showGuide = true
                       }
                   }) {
                       Image(systemName: "lightbulb")
                           .font(.system(size: 22, weight: .bold))
                           .padding(14)
                           .background(Color.yellow.opacity(0.9))
                           .foregroundColor(.white)
                           .clipShape(Circle())
                           .shadow(color: .yellow, radius: 10)
                   }
                   .padding(.trailing)
                   .padding(.bottom)

                   if showGuide {
                       GuideOverlayView(steps: guideSteps, showGuide: $showGuide)
                           .transition(.move(edge: .bottom))
                           .zIndex(1)
                   }
               }
           }
       }
   }

   struct GuideOverlayView: View {
       let steps: [(title: String, message: String)]
       @Binding var showGuide: Bool
       @State private var currentStep = 0

       var body: some View {
           ZStack {
               Color.black.opacity(0.3)
                   .ignoresSafeArea()
                   .onTapGesture {
                       showGuide = false
                   }

               VStack {
                   Spacer()

                   VStack(spacing: 16) {
                       Image(systemName: "lightbulb")
                           .font(.system(size: 32))
                           .foregroundColor(.yellow)

                       Text(steps[currentStep].title)
                           .font(.headline)
                           .foregroundColor(.primary)

                       Text(steps[currentStep].message)
                           .multilineTextAlignment(.center)
                           .font(.subheadline)
                           .foregroundColor(.secondary)

                       Button(action: {
                           withAnimation {
                               if currentStep < steps.count - 1 {
                                   currentStep += 1
                               } else {
                                   showGuide = false
                               }
                           }
                       }) {
                           Text(currentStep < steps.count - 1 ? "Далее" : "Понятно")
                               .bold()
                               .frame(maxWidth: .infinity)
                               .padding()
                               .background(Color.blue)
                               .foregroundColor(.white)
                               .cornerRadius(12)
                       }
                   }
                   .padding()
                   .frame(maxWidth: 340)
                   .background(.ultraThinMaterial)
                   .cornerRadius(20)
                   .shadow(radius: 12)
                   .padding(.horizontal)

                   Spacer().frame(height: 40)
               }
               .frame(height: UIScreen.main.bounds.height * 0.55)
               .transition(.scale)
           }
       }
   }
