//
//  ChatsManager.swift
//  MyHouse
//
//  Created by Азизхон Мансурхонов on 24/05/25.
//
import SwiftUI

class ChatsManager: ObservableObject {
    @Published var chatApartments: [Apartment] = []

    func addChat(for apartment: Apartment) {
        if !chatApartments.contains(where: { $0.id == apartment.id }) {
            chatApartments.append(apartment)
        }
    }

    func removeChat(at offsets: IndexSet) {
        chatApartments.remove(atOffsets: offsets)
    }

    // ✅ Загружаем сообщения из UserDefaults
    func loadMessages(for apartment: Apartment) -> [ChatMessage] {
        return MessageStorage.loadMessages(for: apartment.id)
    }

    // ✅ Сохраняем сообщения в UserDefaults
    func saveMessages(_ messages: [ChatMessage], for apartment: Apartment) {
        MessageStorage.saveMessages(messages, for: apartment.id)
    }
}
