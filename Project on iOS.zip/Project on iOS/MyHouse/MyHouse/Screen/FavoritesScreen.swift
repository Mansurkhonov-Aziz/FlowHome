//
//  FavoritesScreen.swift
//  MyHouse
//
//  Created by Азизхон Мансурхонов on 24/05/25.
//

import SwiftUI

struct FavoritesScreen: View {
    @EnvironmentObject var favoritesManager: FavoritesManager
    @State private var showDeleteConfirmation = false
    @State private var deleteOffsets: IndexSet?

    var body: some View {
        NavigationView {
            List {
                ForEach(favoritesManager.favorites) { apartment in
                    NavigationLink(destination: DetailScreen(apartment: apartment)) {
                        HStack {
                            Image(apartment.images.first ?? "")
                                .resizable()
                                .frame(width: 80, height: 60)
                                .cornerRadius(10)
                            VStack(alignment: .leading) {
                                Text(apartment.title)
                                Text(apartment.price)
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                }
                .onDelete { offsets in
                    deleteOffsets = offsets
                    showDeleteConfirmation = true
                }
            }
            .navigationTitle("Избранные")
            .alert(isPresented: $showDeleteConfirmation) {
                Alert(
                    title: Text("Удалить из избранного? 💔"),
                    message: Text("Вы уверены, что хотите удалить эту квартиру?"),
                    primaryButton: .destructive(Text("Удалить")) {
                        if let offsets = deleteOffsets {
                            delete(at: offsets)
                            deleteOffsets = nil
                        }
                    },
                    secondaryButton: .cancel {
                        deleteOffsets = nil
                    }
                )
            }
        }
    }

    // Удаление через свайп
    func delete(at offsets: IndexSet) {
        for index in offsets {
            let apartment = favoritesManager.favorites[index]
            favoritesManager.toggleFavorite(apartment)
        }
    }
}
