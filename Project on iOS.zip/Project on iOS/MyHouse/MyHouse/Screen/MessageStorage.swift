//
//  MessageStorage.swift
//  FlowHome
//
//  Created by Азизхон Мансурхонов on 25/05/25.
//

import Foundation

class MessageStorage {
    
    // Сохранение сообщений
    static func saveMessages(_ messages: [ChatMessage], for apartmentID: UUID) {
        let key = "messages_\(apartmentID.uuidString)"
        if let data = try? JSONEncoder().encode(messages) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
    
    // Загрузка сообщений
    static func loadMessages(for apartmentID: UUID) -> [ChatMessage] {
        let key = "messages_\(apartmentID.uuidString)"
        if let data = UserDefaults.standard.data(forKey: key),
           let messages = try? JSONDecoder().decode([ChatMessage].self, from: data) {
            return messages
        }
        return []
    }

    // Сохранение номера арендодателя
    static func savePhoneNumber(_ number: String, for apartmentID: UUID) {
        let key = "phone_\(apartmentID.uuidString)"
        UserDefaults.standard.set(number, forKey: key)
    }

    // Загрузка номера арендодателя
    static func loadPhoneNumber(for apartmentID: UUID) -> String? {
        let key = "phone_\(apartmentID.uuidString)"
        return UserDefaults.standard.string(forKey: key)
    }

    // Получение последнего сообщения
    static func lastMessageText(for apartmentID: UUID) -> String? {
        let messages = loadMessages(for: apartmentID)
        return messages.last?.text
    }

    // Получение даты последнего сообщения
    static func lastMessageDate(for apartmentID: UUID) -> String? {
        let messages = loadMessages(for: apartmentID)
        if let last = messages.last {
            let formatter = DateFormatter()
            formatter.dateFormat = "dd.MM"
            return formatter.string(from: last.date)
        }
        return nil
    }
}
