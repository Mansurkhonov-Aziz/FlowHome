//
//  Message.swift
//  MyHouse
//
//  Created by Азизхон Мансурхонов on 24/05/25.
//

import Foundation

struct ChatMessage: Identifiable, Codable {
    let id: UUID
    let text: String
    let isUser: Bool
    let date: Date
}
